FFXI Tex Hammer
by Korith

Version: 1.2.2

https://korithsmods.blogspot.com/p/tex-hammer.html
http://korith.jumpingcrab.com/mods/texhammer.php

To use, just run the exe and then press Load to open a dat file!
From there, enjoy upgrading old low resolution textures.

Requires:
.NET Framework 4.6.1


Changelog:
----------
	1.2.2
		Fixed issue which prevented preview images from updating
		Fixed issue which caused program to crash when using search
	1.2.1
		DXT3 exporting now has a full alpha or clamped alpha option
		Fixed a memory leak
	1.2.0
		UI updated to show previews
		Export
	1.1.0
		Added support for bump maps
	1.0.0
		Updated icon
	RC 1
		Public release


pngquant
--------
Website: http://www.libpng.org/pub/png/apps/pngquant.html

Tex Hammer include pngquant inside of it, which is subject to the following
copyright and liscenses:

Copyright and license info for pngquant:
----------------------------------------

The quantization and dithering code is lifted from Jef Poskanzer's ppmquant,
part of his wonderful PBMPLUS tool suite.  I hacked it into a slightly cheesy
"pamquant" back in 1997 (http://pobox.com/~newt/greg_rgba.html) and finally
ripped out the cheesy file-I/O parts and replaced them with nice PNG code in
December 2000.  The PNG reading and writing code is a merged and slightly
simplified version of readpng, readpng2, and writepng from my book, "PNG:
The Definitive Guide."  pngquant therefore inherits both licenses, one for
each source file.  (Note that both licenses are basically BSD-like; that is,
use the code however you like, as long as you acknowledge its origins.)

pngquant.c:

   Copyright (C) 1989, 1991 by Jef Poskanzer.
   Copyright (C) 1997, 2000 by Greg Roelofs; based on an idea by
                            Stefan Schneider.
  
   Permission to use, copy, modify, and distribute this software and its
   documentation for any purpose and without fee is hereby granted, provided
   that the above copyright notice appear in all copies and that both that
   copyright notice and this permission notice appear in supporting
   documentation.  This software is provided "as is" without express or
   implied warranty.

rwpng.c (and rwpng.h):

   Copyright (c) 1998-2000 Greg Roelofs.  All rights reserved.

   This software is provided "as is," without warranty of any kind,
   express or implied.  In no event shall the author or contributors
   be held liable for any damages arising in any way from the use of
   this software.

   Permission is granted to anyone to use this software for any purpose,
   including commercial applications, and to alter it and redistribute
   it freely, subject to the following restrictions:

   1. Redistributions of source code must retain the above copyright
      notice, disclaimer, and this list of conditions.
   2. Redistributions in binary form must reproduce the above copyright
      notice, disclaimer, and this list of conditions in the documenta-
      tion and/or other materials provided with the distribution.
   3. All advertising materials mentioning features or use of this
      software must display the following acknowledgment:

         This product includes software developed by Greg Roelofs
         and contributors for the book, "PNG: The Definitive Guide,"
         published by O'Reilly and Associates.
