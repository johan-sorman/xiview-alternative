Click Texhammer made by Korith, to start program.

Take one of the 51.dat files with the correct font you want to use and make a copy of it to work on.
Drag that newly made copy into texhammer.

To change the pointer arrow from modded to original, goto images/pointers and drag "anc anc" file into "anc anc" box

To change the mission/npcdialogue pointer drag "anc btwait" into "anc btwait" box.

These only have 2 options, original and modded.

To change the color of macro keys from blue to grey:

Drag either of the 2 files in macro keys folder to the "menu gauge" box

To change the box type for all gear and the equip screen drag and drop the modded or orig file to the "itemslot" box.

To change Job Point stars, pick aspect ratio folder and drag and drop into the "menu ustashd" box near the bottom.

Press save at the top right next to generate thumbnails and drop that resulting file into the rom/119 folder.

